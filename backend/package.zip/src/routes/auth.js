import express from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { body, validationResult } from 'express-validator';
import { pool } from '../config/database.js';

const router = express.Router();

// Register endpoint
router.post('/register', [
  body('companyName').notEmpty().withMessage('Company name is required'),
  body('businessType').notEmpty().withMessage('Business type is required'),
  body('industry').notEmpty().withMessage('Industry is required'),
  body('companyLocation').notEmpty().withMessage('Company location is required'),
  body('fullName').notEmpty().withMessage('Full name is required'),
  body('email').isEmail().withMessage('Valid email is required'),
  body('password').isLength({ min: 8 }).withMessage('Password must be at least 8 characters')
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const {
      companyName,
      businessType,
      industry,
      companySize,
      companyLocation,
      fullName,
      email,
      phone,
      password
    } = req.body;

    // Check if user already exists
    const [existingUsers] = await pool.execute(
      'SELECT id FROM users WHERE email = ?',
      [email]
    );

    if (existingUsers.length > 0) {
      return res.status(400).json({ error: 'User already exists with this email' });
    }

    // Start transaction
    const connection = await pool.getConnection();
    await connection.beginTransaction();

    try {
      // Create company
      const [companyResult] = await connection.execute(
        'INSERT INTO companies (name, business_type, industry, size, location) VALUES (?, ?, ?, ?, ?)',
        [companyName, businessType, industry, companySize, companyLocation]
      );

      const companyId = companyResult.insertId;

      // Hash password
      const hashedPassword = await bcrypt.hash(password, 12);

      // Create user
      await connection.execute(
        'INSERT INTO users (company_id, full_name, email, phone, password, role) VALUES (?, ?, ?, ?, ?, ?)',
        [companyId, fullName, email, phone, hashedPassword, 'admin']
      );

      await connection.commit();
      connection.release();

      // Generate JWT token
      const token = jwt.sign(
        { email, companyId, role: 'admin' },
        process.env.JWT_SECRET,
        { expiresIn: process.env.JWT_EXPIRES_IN }
      );

      res.status(201).json({
        message: 'Registration successful',
        token,
        user: { email, fullName, companyName }
      });

    } catch (error) {
      await connection.rollback();
      connection.release();
      throw error;
    }

  } catch (error) {
    console.error('Registration error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Login endpoint
router.post('/login', [
  body('email').isEmail().withMessage('Valid email is required'),
  body('password').notEmpty().withMessage('Password is required')
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { email, password, company } = req.body;

    // Find user with company information
    const [users] = await pool.execute(`
      SELECT u.*, c.name as company_name, c.business_type, c.industry 
      FROM users u 
      JOIN companies c ON u.company_id = c.id 
      WHERE u.email = ?
    `, [email]);

    if (users.length === 0) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const user = users[0];

    // Verify password
    const isPasswordValid = await bcrypt.compare(password, user.password);
    if (!isPasswordValid) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    // Generate JWT token
    const token = jwt.sign(
      { 
        userId: user.id, 
        email: user.email, 
        companyId: user.company_id, 
        role: user.role 
      },
      process.env.JWT_SECRET,
      { expiresIn: process.env.JWT_EXPIRES_IN }
    );

    res.json({
      message: 'Login successful',
      token,
      user: {
        id: user.id,
        email: user.email,
        fullName: user.full_name,
        companyName: user.company_name,
        role: user.role
      }
    });

  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Forgot password endpoint
router.post('/forgot-password', [
  body('email').isEmail().withMessage('Valid email is required')
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { email } = req.body;

    // Check if user exists
    const [users] = await pool.execute(
      'SELECT id FROM users WHERE email = ?',
      [email]
    );

    if (users.length === 0) {
      // Don't reveal that email doesn't exist for security
      return res.json({ 
        message: 'If the email exists, a reset link has been sent' 
      });
    }

    // Generate reset token (in real app, send email)
    const resetToken = jwt.sign(
      { email },
      process.env.JWT_SECRET,
      { expiresIn: '1h' }
    );

    // Store reset token in database
    await pool.execute(
      'UPDATE users SET reset_token = ?, reset_token_expiry = DATE_ADD(NOW(), INTERVAL 1 HOUR) WHERE email = ?',
      [resetToken, email]
    );

    // In production, you would send an email here
    console.log('Password reset token:', resetToken);

    res.json({ 
      message: 'If the email exists, a reset link has been sent' 
    });

  } catch (error) {
    console.error('Forgot password error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

export default router;